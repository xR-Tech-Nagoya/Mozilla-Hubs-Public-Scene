This bar space is the space that will be used in cluster, which is a VR SNS made in Japan. A movie director of my friend uses it for the screening of his own movie.

I will publish the Unity package after the space is created.

Eventually we will start working on compatibility with Hubs. At that time, it will be updated to the public space so that anyone can handle it.

このバー空間は、日本産のVRSNSであるclusterで使う予定の空間です。私の友人の映画監督が自作映画の上映会に使用します。

私は空間の制作終了後、Unitypackageの公開をします。

最終的にはHubsへの互換作業を開始します。その際、パブリック空間へとアップデートをし誰もが扱えるようになります。